import createFactory from './patch'

export default createFactory('component')
