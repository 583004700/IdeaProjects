# mpx文档

该仓库为mpx文档仓库，使用gitbook搭建文档网站。

修改文档可直接修改md文件，提交后会自动部署到[github pages](https://didi.github.io/mpx)

若有较复杂的改动，需本地预览效果需先安装gitbook： `npm i -g gitbook-cli`  
安装gitbook插件 `gitbook install`
然后在本目录下 `gitbook serve`
