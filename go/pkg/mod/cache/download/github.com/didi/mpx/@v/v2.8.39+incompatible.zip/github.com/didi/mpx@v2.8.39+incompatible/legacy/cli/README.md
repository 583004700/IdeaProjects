# `mpx-cli`

> MPX CLI is the Standard Tooling for MPX project Development.

## Installation

```bash
npm i @mpxjs/cli
```

## Usage

```bash
mpx init <project-name>
```
