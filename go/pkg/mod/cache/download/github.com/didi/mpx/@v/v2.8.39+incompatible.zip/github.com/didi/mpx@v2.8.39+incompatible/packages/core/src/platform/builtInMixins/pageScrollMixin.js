export default function pageScrollMixin () {
  return {}
}
