import SelectQuery from './SelectQuery'

function createSelectorQuery () {
  return new SelectQuery()
}

export {
  createSelectorQuery
}
