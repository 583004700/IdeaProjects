module.exports = require('./SizeReportPlugin')
