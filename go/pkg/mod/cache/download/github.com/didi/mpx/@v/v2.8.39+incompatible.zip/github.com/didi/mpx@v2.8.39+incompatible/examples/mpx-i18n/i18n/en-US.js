module.exports = {
  message: {
    hello: '{msg} world'
  },
  welcome: {
    intro: 'this is an example of using i18n with mpx framework'
  }
}
