export const RefKey = '__composition_api_ref_key__'
export const ObKey = '__ob__'

export const PausedState = {
  paused: 0,
  dirty: 1,
  resumed: 2
}

export const DefaultLocale = 'zh-CN'
