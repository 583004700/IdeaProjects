module.exports = {
  static: false,
  allowedHosts: 'auto',
  compress: true,
  client: {
    overlay: {
      errors: true,
      warnings: false
    }
  },
  port: 'auto'
}
