<template>
  <div class="swiper-item">
    <slot></slot>
  </div>
</template>
    
<script>
export default {};
</script>
    
<style scoped>
.swiper-item {
  width: 100%;
}
img {
  display: block;
  width: 100%;
  height: 100%;
}
</style>
