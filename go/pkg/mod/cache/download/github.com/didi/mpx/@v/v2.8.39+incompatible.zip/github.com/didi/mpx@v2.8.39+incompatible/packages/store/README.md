# `mpx-store`

> A store for mpx framework

## Usage https://mpxjs.cn/guide/advance/store.html
