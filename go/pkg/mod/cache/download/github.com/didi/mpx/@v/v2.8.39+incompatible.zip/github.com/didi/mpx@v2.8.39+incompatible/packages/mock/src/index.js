import xmock from './xmock'
export default xmock
