# `mpx-mock`

> a http request lib for mpx framework.

## Usage

```js
import mock from '@mpxjs/mock'


mock([{
  url,
  rule
}])
```
