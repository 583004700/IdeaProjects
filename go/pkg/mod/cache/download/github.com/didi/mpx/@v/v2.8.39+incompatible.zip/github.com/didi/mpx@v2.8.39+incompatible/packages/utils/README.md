# `mpx-utils`

> A toolkit for mpx framework

## Usage


```js
import { xxx } from '@mpxjs/utils'
```