<script>
import ApiIndex from './ApiIndex.vue';

export default {
  components: {
    ApiIndex
  }
}
</script>

<ApiIndex></ApiIndex>
