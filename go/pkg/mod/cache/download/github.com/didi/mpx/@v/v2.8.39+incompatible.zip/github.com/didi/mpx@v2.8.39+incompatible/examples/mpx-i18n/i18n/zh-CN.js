module.exports = {
  message: {
    hello: '{msg} 世界'
  },
  welcome: {
    intro: '这是mpx框架提供的i18n能力演示用的小程序'
  }
}
