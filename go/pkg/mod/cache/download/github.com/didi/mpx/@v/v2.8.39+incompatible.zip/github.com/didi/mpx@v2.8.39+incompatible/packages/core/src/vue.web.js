import Vue from 'vue'
import install from './vuePlugin'

Vue.use(install)

export default Vue
