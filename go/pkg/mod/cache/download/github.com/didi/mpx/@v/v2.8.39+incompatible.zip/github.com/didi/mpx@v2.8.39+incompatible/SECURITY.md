# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 2.6.x   | :white_check_mark: |
| < 2.6   | :x:                |

## Reporting a Vulnerability

To report a vulnerability please send an email with the details to [674883329@qq.com](674883329@qq.com) or [17801031786@163.com](17801031786@163.com).

We will do our best to fix the problem as soon as possible.

Thank you for helping us to keep secure.
