Page({
  data: {
    name: 'name1'
  }
})
