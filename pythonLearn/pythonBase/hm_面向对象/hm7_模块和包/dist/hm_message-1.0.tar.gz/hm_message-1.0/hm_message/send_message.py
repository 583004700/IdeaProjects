from hm_面向对象.hm7_模块和包.hm_模块1 import *


def send(text):
    print("正在发送..."+text)
    dog = Dog("小狗")
    dog.run()