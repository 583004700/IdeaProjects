def receive():
    return "这是来自100XX的短信"
